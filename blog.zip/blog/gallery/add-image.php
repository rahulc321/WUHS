<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel: upload multiple file using dropzone.js</title>
    <link href="http://demo.expertphp.in/css/dropzone.css" rel="stylesheet">
    <script src="http://demo.expertphp.in/js/dropzone.js"></script>
</head>
<body>
<h3>PHP : Upload multiple file using dropzone.js with drag and drop features</h3>
<form action="upload.php" class="dropzone">
</form>
</body>
</html>