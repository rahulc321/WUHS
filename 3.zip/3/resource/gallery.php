<!DOCTYPE html>
<html lang="en" dir="ltr" prefix="content: http://purl.org/rss/1.0/modules/content/  dc: http://purl.org/dc/terms/  foaf: http://xmlns.com/foaf/0.1/  og: http://ogp.me/ns#  rdfs: http://www.w3.org/2000/01/rdf-schema#  schema: http://schema.org/  sioc: http://rdfs.org/sioc/ns#  sioct: http://rdfs.org/sioc/types#  skos: http://www.w3.org/2004/02/skos/core#  xsd: http://www.w3.org/2001/XMLSchema# ">
  
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.1">
	<meta charset="utf-8" />
<link rel="stylesheet" href="../modules/contrib/d8_google_optimize_hide_page/d8_google_optimize_hide_page.css" />
<script src="../d8_google_optimize_hide_page/snippet"></script>
<script src="../sites/g/files/krcnkv261/files/google_tag/ross_med_default/google_tag.script7422.js?qrgqy9" defer></script>
<script src="../../cdn.cookielaw.org/scripttemplates/otSDKStub.js" data-domain-script="0efa9c34-3840-4c58-a0de-4972a65cf45d" defer></script>

<link rel="canonical" href="newsroom.html" />

<meta name="Generator" content="Drupal 8 (https://www.drupal.org)" />
<meta name="MobileOptimized" content="width" />
<meta name="HandheldFriendly" content="true" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="preload" href="../themes/custom/rum_base/fonts/rockwell/f60b9b8c-1fb9-43fc-a776-1ed969eec0b6.html" as="font" crossorigin="anonymous" />
<link rel="preload" href="../themes/custom/rum_base/fonts/rum-icomoon/fonts/rum-icomoon4091.html?y16ofo" as="font" crossorigin="anonymous" />
<link rel="preload" href="../themes/custom/rum_base/fonts/rum-icomoon/fonts/rum-icomooncf41.html?ql7to1" as="font" crossorigin="anonymous" />
<link rel="preload" href="../themes/custom/rum_base/fonts/helvetica-neue/08b57253-2e0d-4c12-9c57-107f6c67bc49.html" as="font" crossorigin="anonymous" />
<link rel="preload" href="../themes/custom/rum_base/fonts/helvetica-neue/800da3b0-675f-465f-892d-d76cecbdd5b1.html" as="font" crossorigin="anonymous" />
<link rel="shortcut icon" href="../themes/custom/rum_base/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="revision" href="newsroom.html" />

    <title>Washington University of Health and Science</title>
    <link rel="stylesheet" media="all" href="../sites/g/files/krcnkv261/files/css/css_2S9DG6UixTwtM3A136SQrK3GooPuLGn-VbPMdVAjgPQ.css" />
<link rel="stylesheet" media="all" href="../sites/g/files/krcnkv261/files/css/css_O0PnYZ5ux66KWgNNcqpUzUQT3O1fyLA0cl27JGXmR-4.css" />

    <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"","currentPath":"node\/3961","currentPathIsAdmin":false,"isFront":false,"currentLanguage":"en"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"ajaxPageState":{"libraries":"anchor_link\/drupal.anchor_link,atge_analytics\/atge_analytics_livechat,atge_base\/accordion-menus,atge_base\/alternate_header,atge_base\/analytics,atge_base\/global,atge_base\/mega-menu,atge_base\/mobile-menu,atge_base\/stickyheader,atge_ccpa_onetrust\/ccpa_button,atge_components_banner\/banner-image,atge_components_richtext\/richtext,atge_external_js\/atge_external_js,atge_external_links\/external_links,atge_live_chat\/atge_live_chat,atge_live_chat\/atge_live_chat_gdpr,atge_tint\/atge_tint,atge_utility\/geofeed,classy\/base,classy\/messages,classy\/node,core\/html5shiv,core\/normalize,datalayer\/behaviors,entity_embed\/caption,gdpr_onetrust\/gdpr-onetrust-api,paragraphs\/drupal.paragraphs.unpublished,rum_base\/cookies,rum_base\/grid_truncator,rum_base\/header-mainnav,rum_base\/header-searchform,rum_base\/theme,seckit\/integrity,seckit\/sha256,system\/base,tb_megamenu\/theme.tb_megamenu,views\/views.ajax,views\/views.module","theme":"rum_base","theme_token":null},"ajaxTrustedUrl":{"\/search":true},"atge_external_js":{"files":null,"excluded":null,"disable_admin":null,"disable_front":null},"atge_gdpr_global":{"youtube_gdpr_text":"Please accept cookies to play this video. By accepting you will be accessing a service provided by a third party."},"atge_live_chat":{"chat_enable":1,"sticky_enable":1,"sf_env_live":"https:\/\/d.la1-c1-ph2.salesforceliveagent.com\/chat","deploy_id_live":"5728000000000tS","org_id_live":"00D80000000cFjT","sf_env_proactive":"https:\/\/d.la1-c1-ph2.salesforceliveagent.com\/chat","deploy_id_proactive":"5728000000000tX","org_id_proactive":"00D80000000cFjT","enable_new_workflow":1,"isGdprEnabled":true},"atge_tint":{"include_paths":"\/\r\n\/about\/*\r\n\/node\/3961\/layout"},"atge_utility":{"enable_new_workflow":1,"isGdprEnabled":true},"dataLayer":{"defaultLang":"en","languages":{"en":{"id":"en","name":"English","direction":"ltr","weight":0}}},"views":{"ajax_path":"\/views\/ajax","ajaxViews":{"views_dom_id:c6d73990e996abc535bb53ea0116e9bc7668ee1e3aad1f2ff9d0537de096e4bb":{"view_name":"atge_news_tagged_listing","view_display_id":"atge_news_tagged_featured_block","view_args":"516","view_path":"\/node\/3961","view_base_path":null,"view_dom_id":"c6d73990e996abc535bb53ea0116e9bc7668ee1e3aad1f2ff9d0537de096e4bb","pager_element":0},"views_dom_id:924a2fa693c655b42fc29084214ab9b27459fbaaa54385534a16de6dac6503be":{"view_name":"atge_news_tagged_listing","view_display_id":"atge_news_tagged_featured_block","view_args":"246+236","view_path":"\/node\/3961","view_base_path":null,"view_dom_id":"924a2fa693c655b42fc29084214ab9b27459fbaaa54385534a16de6dac6503be","pager_element":0},"views_dom_id:96cf59e7ab09d48b0efa6a751e1b15fedb2893d24ef4a338baaa1da346f5754c":{"view_name":"atge_news_tagged_listing","view_display_id":"atge_news_tagged_featured_block","view_args":"41","view_path":"\/node\/3961","view_base_path":null,"view_dom_id":"96cf59e7ab09d48b0efa6a751e1b15fedb2893d24ef4a338baaa1da346f5754c","pager_element":0},"views_dom_id:ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8":{"view_name":"atge_news_tagged_listing","view_display_id":"atge_news_tagged_featured_block","view_args":"511","view_path":"\/node\/3961","view_base_path":null,"view_dom_id":"ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8","pager_element":0}}},"TBMegaMenu":{"TBElementsCounter":{"column":2},"theme":"rum_base"},"atge_external_links":{"external_links":{"onswitch":null,"whitelist":[],"modal":{"delay":null}}},"seckit":{"integrity":{"subresource_integrity":false,"subresource_crossorigin":false}},"atge_base":{"global":{"theme_abbv":"rum"}},"ajax":[],"user":{"uid":0,"permissionsHash":"8d0a8546a3715fd61e06e7d60015eaeb0a72f5a3d70d860c1ce367a30a1b6704"}}</script>

<!--[if lte IE 8]>
<script src="/sites/g/files/krcnkv261/files/js/js_VtafjXmRvoUgAzqzYTA3Wrjkx9wcWhjP0G4ZnnqRamA.js"></script>
<![endif]-->
<script src="../sites/g/files/krcnkv261/files/js/js_6Q1vPz50-Ilt7QwIkxruuQP5KmOFvD1_aN4vvwBy_l0.js"></script>

  </head>
  <body class="path-node page-node-type-page">
        <a role="navigation" aria-label="skip-to-main-content" href="#main-content" class="visually-hidden focusable skip-link">
      Skip to main content
    </a>
    <noscript aria-hidden="true"><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P23DMCS" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
      <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
    	<div class="layout-container">
		<header role="banner" class="page--header">
			
      <div class="region region__mobile">
                    
      
    
  
  

        <div class="menu__mobile--wrapper">

      <div class="menu__mobile--header">

        <div class="flexrow">
          <div class="flexitem header--branding">
              
<div id="block-rum-base-branding" data-block-plugin-id="system_branding_block" class="block block-system block-system-branding-block block__site-logo region--header">
        <a href="../index.html" title="Home" rel="home" class="e-logo" onClick="Drupal.behaviors.atgeAnalytics.navClick('Header', 'logo')">
      <img loading="lazy" src="../images/logo.png" alt="Home" />
    </a>
  </div>

          </div>
          <div class="flexitem header--mobile-menu">
                          <div class="menu-button">
                <span class="e-icon icon-rum-menu"></span>
                <span>Menu</span>
              </div>
                      </div>
        </div>

      </div>

      
    </div>
  
                        </div>
  
			
			
      <div class="region region__header">
      
<div class="grid__container">
<div class="grid__container--items">

            
    <div class="flexrow">
     <div class="flexitem">
       
<div id="block-rum-base-branding" data-block-plugin-id="system_branding_block" class="block block-system block-system-branding-block block__site-logo region--header">
        <a href="../index.html" title="Home" rel="home" class="e-logo" onClick="Drupal.behaviors.atgeAnalytics.navClick('Header', 'logo')">
      <img loading="lazy" src="../images/logo.png" alt="Home" />
    </a>
  </div>

     </div>
     <div class="flexitem">
       <div class="items-inline">
         


<nav aria-labelledby="system-menu-blocksecondary-block-secondarynavigation-header" id="block-secondarynavigation" data-block-plugin-id="system_menu_block:secondary" class="block block-menu navigation menu--secondary">
            
  <h3 class="visually-hidden" id="system-menu-blocksecondary-block-secondarynavigation-header">Secondary Navigation</h3>
  

        
              <ul region="header" class="menu">
                                 <li class="menu-item menu-item--collapsed">
                                    <a href="alumni.html" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Header&#039;, &#039;Alumni&#039;)" data-drupal-link-system-path="node/706">Alumni</a>
								 </li>
                                 <li class="menu-item menu-item--collapsed">
                                    <a href="../student-life/matched-future-doctors.html" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Header&#039;, &#039;Current Students&#039;)" data-drupal-link-system-path="node/91">Students</a>
                                  </li>
                                 <li class="menu-item menu-item--collapsed">
                                   <a href="../student-life/international-students.html" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Header&#039;, &#039;Admitted Students&#039;)" data-drupal-link-system-path="node/2381">International Students</a>
                                 </li>
                                 </ul>
  


  </nav>
  </div>
    <!--menu-->			
       <nav class="block block-tb-megamenu block-tb-megamenu-menu-blockmain block__menu--main">
                     <h3 class="visually-hidden" id="block-mainnavigation-menu">Main navigation</h3>
			         <div  class="tb-megamenu tb-megamenu-main" role="navigation">
                     <div class="tb-megamenu-nav--wrapper ">
                     <ul  class="tb-megamenu-nav nav level-0 items-6" role="list">
                          <li  class="tb-megamenu-item level-1 mega dropdown" >
                          <a href='admissions.html'  class="dropdown-toggle" >Admissions
                         <span class="caret"></span>
                         <span class="caret"></span>
                          </a>
                                <div  class="tb-megamenu-submenu dropdown-menu mega-dropdown-menu nav-child" data-class="" data-width="" role="list">
                                 <div class="mega-dropdown-inner">
                                   <div  class="tb-megamenu-row row-fluid">
                                  <div  class="tb-megamenu-column span12 mega-col-nav" data-class="" data-width="12" data-hidewcol="0" id="tb-megamenu-column-1">
                                  <div class="tb-megamenu-column-inner mega-inner clearfix">
                                   <ul  class="tb-megamenu-subnav mega-nav level-1 items-15" role="list">        
                                   <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions-overview.html' > Admissions Overview <span class="caret"></span></a>
                                   </li>
							       <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/how-to-apply.html'>How To Apply<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/start-your-career.html'>Start Your Career<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega" >
                                   <a href='../admissions/admissions-requirements.html' >Admission Requirements<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/admission-process.html' >Admission Process<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega" >
                                   <a href='../admissions/tuition-and-fees.html' >Tuition and Fees<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/scholarships.html' >Scholarships<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/canadian-loans.html' >Canadian Loans<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega" >
                                   <a href='../admissions/payment-plans.html' >Payment Plans <span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/merchant-information.html'>Merchant Information<span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/finance-options.html' >Finance Options <span class="caret"></span></a>   
                                  </li>
								  <li  class="tb-megamenu-item level-2 mega">
                                   <a href='../admissions/transcript-request.html' >Transcript Request <span class="caret"></span></a>   
                                  </li>
                                  </ul>

                              </div>
                             </div>

                            <div class="mega-dropdown__close"></div>
                            </div>

                            </div>
                               </div>

                             </li>

                        <li  class="tb-megamenu-item level-1 mega dropdown">
                         <a href='#'  class="dropdown-toggle" title="Academic">Academic<span class="caret"></span><span class="caret"></span>
                         </a>
                          <div  class="tb-megamenu-submenu dropdown-menu mega-dropdown-menu nav-child">
                         <div class="mega-dropdown-inner">
                             <div  class="tb-megamenu-row row-fluid">
                                <div  class="tb-megamenu-column span12 mega-col-nav" data-class="" data-width="12" data-hidewcol="0" id="tb-megamenu-column-2">
                                   <div class="tb-megamenu-column-inner mega-inner clearfix">
                                       <ul  class="tb-megamenu-subnav mega-nav level-1 items-7" role="list">
                                         <li  class="tb-megamenu-item level-2 mega" >
                                          <a href='../academic-overview.html' >Academic Overview<span class="caret"></span></a>
                                         </li>   
                                         <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/pre-medical.html' >Pre-Medical Program<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/basic-science.html' >Pre-Clinical  Program<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                          <a href='../md-program/md-program.html' >MD Program<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/curriculum.html'>Curriculum<span class="caret"></span> </a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega">
                                         <a href='../md-program/clinical-sciences.html'>Pre-Clinical Curriculum <span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega">
                                          <a href='../md-program/clinical-rotations.html' >Clinical Rotations <span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega">
                                         <a href='../md-program/clinical-experience.html'>Clinical Experience <span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                          <a href='../md-program/foundational-training.html' >Foundational Training <span class="caret"></span></a>
										  </li>
										  <li class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/research.html' >Research <span class="caret"></span>
                                          </a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/academic-calendar.html'  >Academic Calendar <span class="caret"></span>
                                          </a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../md-program/faculty.html' >Faculty <span class="caret"></span>
                                          </a>
										  </li>
                                         </ul>

                                         </div>
                                     </div>

                                    <div class="mega-dropdown__close"></div>
                                    </div>
									</div>
									</div>
						</li>
						<li  class="tb-megamenu-item level-1 mega dropdown">
                         <a href='#'  class="dropdown-toggle" title="Student">Student<span class="caret"></span><span class="caret"></span>
                         </a>
                          <div  class="tb-megamenu-submenu dropdown-menu mega-dropdown-menu nav-child">
                         <div class="mega-dropdown-inner">
                             <div  class="tb-megamenu-row row-fluid">
                                <div  class="tb-megamenu-column span12 mega-col-nav" data-class="" data-width="12" data-hidewcol="0" id="tb-megamenu-column-2">
                                   <div class="tb-megamenu-column-inner mega-inner clearfix">
                                       <ul  class="tb-megamenu-subnav mega-nav level-1 items-7" role="list">
                                         <li  class="tb-megamenu-item level-2 mega" >
                                          <a href='../student-life/matched-future-doctors.html' >MATCHED FUTURE DOCTORS<span class="caret"></span></a>
                                         </li>   
                                         <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/life-at-wuhs-overview.html' >Life On Campus<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/about-belize.html' >About Belize<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/traveling-to-belize.html' >Traveling to Belize<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/international-students.html' >International Students<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/student-testimonials.html' >Student Testimonials<span class="caret"></span></a>
										  </li>
										   <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/student-supportive-services.html' >Student Services<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/student-government-association.html' >Student Government Association<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/sga-executive-committee.html' >SGA – EXECUTIVE COMMITTEE<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/about-sga.html' >About SGA<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/events.html' >Schedule of Events<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='https://www.facebook.com/groups/173454076147912/?ref=br_tf' target='_blank'  >Student Facebook Page<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/canadian-students.html'  >Canadian Students<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='../student-life/south-asian-students.html'  >South Asian Students<span class="caret"></span></a>
										  </li>
                                         </ul>

                                         </div>
                                     </div>

                                    <div class="mega-dropdown__close"></div>
                                    </div>
									</div>
									</div>
						</li>
						<li  class="tb-megamenu-item level-1 mega dropdown">
                         <a href='#'  class="dropdown-toggle" title="Student">Resource<span class="caret"></span><span class="caret"></span>
                         </a>
                          <div  class="tb-megamenu-submenu dropdown-menu mega-dropdown-menu nav-child">
                         <div class="mega-dropdown-inner">
                             <div  class="tb-megamenu-row row-fluid">
                                <div  class="tb-megamenu-column span12 mega-col-nav" data-class="" data-width="12" data-hidewcol="0" id="tb-megamenu-column-2">
                                   <div class="tb-megamenu-column-inner mega-inner clearfix">
                                       <ul  class="tb-megamenu-subnav mega-nav level-1 items-7" role="list">
                                         <li  class="tb-megamenu-item level-2 mega" >
                                          <a href='coronavirus-response.html' >Coronavirus Response<span class="caret"></span></a>
                                         </li>   
                                         <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='news.html' >News<span class="caret"></span></a>
										  </li>
										   <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='blog.html' >Blog<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='downloads.html' >Downloads<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='medical-resource.html' >Medical Resources<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='alumni.html' >Alumni<span class="caret"></span></a>
										  </li>
										  <li  class="tb-megamenu-item level-2 mega" >
                                         <a href='gallery.html' >Photo Gallery<span class="caret"></span></a>
										  </li>
										  
                                         </ul>

                                         </div>
                                     </div>

                                    <div class="mega-dropdown__close"></div>
                                    </div>
									</div>
									</div>
						</li>
						<li  class="tb-megamenu-item level-1 mega dropdown">
                         <a href='#'  class="dropdown-toggle" title="Student">About<span class="caret"></span><span class="caret"></span>
                         </a>
                          <div  class="tb-megamenu-submenu dropdown-menu mega-dropdown-menu nav-child">
                         <div class="mega-dropdown-inner">
                             <div  class="tb-megamenu-row row-fluid">
                                <div  class="tb-megamenu-column span12 mega-col-nav" data-class="" data-width="12" data-hidewcol="0" id="tb-megamenu-column-2">
                                   <div class="tb-megamenu-column-inner mega-inner clearfix">
                                       <ul  class="tb-megamenu-subnav mega-nav level-1 items-7" role="list">
                                         <li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about-overview.html'>Welcome <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/mission.html'>Mission, Vision, & Values <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega" >
                                                       <a href='../about/executive-leadership.html' >Executive  Leadership <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/vice-president.html' >Executive Vice President <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/academic-dean.html' >Academic Dean <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/clinical-science-dean.html' >Dean of Clinical Sciences <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/recognition.html' >Recognition <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/belize-partnership.html' >Belize Partnership <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/careers.html' >Careers <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../about/global-partnership.html' >Global Partnership <span class="caret"></span></a>
												    </li>
													<li  class="tb-megamenu-item level-2 mega">
                                                       <a href='../contact-admissions.html' >Contact us <span class="caret"></span></a>
												    </li>
										  
                                         </ul>

                                         </div>
                                     </div>

                                    <div class="mega-dropdown__close"></div>
                                    </div>
									</div>
									</div>
						</li>
                        <li  class="tb-megamenu-item level-1 mega call-to-action large-only dropdown">
                                <a href='../admissions/how-to-apply.html'>Apply Now <span class="caret"></span><span class="caret"></span></a>
                                    
						</li>
                        <li  class="tb-megamenu-item level-1 mega call-to-action large-only" >
                                   <a href='../contact-admissions.html' >Request Info<span class="caret"></span></a>
                        </li>
					</ul>
		</div>
	</div>
    </nav>
       






     </div>
    </div>
  
      </div>
</div>
    </div>
  
		</header>
			
		
	
      <div class="region region__admin">
      <div class="grid__container">
<div class="grid__container--items">

                <div data-drupal-messages-fallback class="hidden"></div>

      
      </div>
</div>
    </div>
  

	<main role="main" class="page--main">
		<a id="main-content" tabindex="-1"></a>
		
		<div class="layout-content">
			
      <div class="region region__content">
                    
                <div id="block-rum-base-content" data-block-plugin-id="system_main_block" class="block block-system block__system-main-block">

  
    

    
      


<article role="article" about="/about/newsroom" class="node__page node__rum-page node__page--full node__rum-page--full node node--type-page node--view-mode-full">

  
    <div class="node__content">
      
													<div class="t-layout__one-column edge-to-edge no-padding no-max-width layout__bg--none layout layout--atge-one-column" >
				<div class="grid__container">
					<div class="layout__regions grid__container--items" >
																								</div>
				</div>
			</div>
			
													<div class="t-layout__one-column edge-to-edge no-padding no-max-width layout__bg--none layout layout--atge-one-column" >
				<div class="grid__container">
					<div class="layout__regions grid__container--items" >
																					<div  class="layout__region layout__region--main grid__container--item">
									<div data-block-plugin-id="extra_field_block:node:page:links" class="block block-layout-builder block__extra-field-blocknodepagelinks">

  
    

    
      
  
    
</div>
<div data-block-plugin-id="inline_block:component_banner" data-inline-block-uuid="e47a9d59-d948-4fac-b1b2-3d79ec52786b" class="c-banner c-rum-banner block block-layout-builder block__inline-blockcomponent-banner">

  
    

    
      
  
      <div class="c-banner--items c-rum-banner--items paragraph paragraph--type--atge-banner paragraph--view-mode--default c-atge-banner c-atge-banner--default">
        
      <div class="c-banner--item c-rum-banner--item p-banner__bg-color--brand-primary p-banner__align--center-right c-banner__mobile--natural p-banner__align--vert-fill c-banner__layout--twocol paragraph paragraph--type--atge-banner-item paragraph--view-mode--default c-atge-banner-item c-atge-banner-item--default">
      
    

    
  <div class="p-rum-banner__media p-atge-banner-item--media p-banner__media ">
    
    
    
      </div>

      <div class="p-rum-banner__content p-atge-banner-item--content p-banner__content c-banner__content--items">
      
      <div class="c-banner__content--item c-banner__media--item c-rum-banner__content--item c-rum-banner__media--item has-objectfit paragraph paragraph--type--atge-banner-item-media paragraph--view-mode--default c-atge-banner-item-media c-atge-banner-item-media--default">
        <img  src="../images/resource/6.jpg" typeof="foaf:Image" class="image-style-atge-no-style-lg" />


    </div>
  

      <div class="c-banner__content--item c-banner__text--item c-rum-banner__content--item c-rum-banner__text--item p-banner__txt-bg--plain p-banner__txt-color--light p-banner__width--full p-banner__mtx--drop p-banner__mtx-align--left paragraph paragraph--type--atge-banner-item-text paragraph--view-mode--default c-atge-banner-item-text c-atge-banner-item-text--default">
      
  <div class="c-banner__content--inner p-rum-banner__content--inner  c-banner__text--inner">      <h1 class="p-rum-banner--heading p-atge-banner-item-text--heading p-banner-heading">
      WUHS Gallery
      </h1>
    
    
          <div class="p-rum-banner--copy p-atge-banner-item-text--copy p-banner-copy">
        <hr />
      </div>
    
      </div>

    </div>
  

    </div>
  
    </div>
  

    </div>
  


  
    
</div>

								</div>
																		</div>
				</div>
			</div>
			
													<div class="t-layout__one-column edge-to-edge no-padding no-max-width layout__bg--none hide-on-desktop layout layout--atge-one-column" >
				<div class="grid__container">
					<div class="layout__regions grid__container--items" >
																					<div  class="layout__region layout__region--main grid__container--item">
									<div data-block-plugin-id="inline_block:component_richtext" data-inline-block-uuid="33902f3b-e88e-4c51-9001-74c16dfa6806" class="c-richtext c-rum-richtext block block-layout-builder block__inline-blockcomponent-richtext">

  
    

    
      
  
      <div class="c-richtext__content c-rum-richtext__content paragraph paragraph--type--atge-rich-text paragraph--view-mode--default c-atge-rich-text c-atge-rich-text--default">
        
      <div class="c-richtext__content--inner c-rum-richtext__content--inner">
      <p> </p>

<p> </p>

    </div>
      </div>
  


  
    
</div>

								</div>
																		</div>
				</div>
			</div>
			
			
			<!--Firstt-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">WUHS Belize Campus</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            <!---First row-->
            
            <?php
            $imageArray= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg',
            '6.jpg',
            '7.jpg',
            '8.jpg',
            '9.jpg',
            '10.jpg',
            '11.jpg'
            );
            
            for($i=0; $i<=10;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/campus/<?=$imageArray[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            
            
        <!--Second-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">San Pedro Ambergris Caye</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $imageArray2= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg',
            '6.jpg',
            '7.jpg',
            '8.jpg',
            '9.jpg',
            '10.jpg',
            '11.jpg',
            '12.jpg'
            );
            
            for($i=0; $i<=11;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/san/<?=$imageArray2[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            
             <!--Start 3rd-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">Student</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $student= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg'
            );
            
            for($i=0; $i<=4;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/student/<?=$student[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--End 3rd-->
            
            
            
             <!--Internal-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">INTERNAL MEDICINE</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $internal= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg',
            '6.jpg',
            '7.jpg'
            );
            
            for($i=0; $i<=6;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/internal/<?=$internal[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--Internal-->
            
             <!--CLINICAL ROTATION - MIAMI, FL-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">CLINICAL ROTATION - MIAMI, FL</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $car= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg',
            '6.jpg'
            );
            
            for($i=0; $i<=5;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/car/<?=$car[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--CLINICAL ROTATION - MIAMI, FL-->
            
            
             <!--CLINICAL ROTATION - ATLANTA, GA-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">CLINICAL ROTATION - ATLANTA, GA</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $cal= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg'
            );
            
            for($i=0; $i<=3;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/cl/<?=$cal[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--CLINICAL ROTATION - ATLANTA, GA-->
            
            
             <!--CLASSROOM-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">CLASSROOM</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $cls= array(
            '1.jpg',
            '2.jpg',
            '3.jpg',
            '4.jpg',
            '5.jpg',
            '6.jpg',
            '7.jpg',
            '8.jpg',
            '9.jpg',
            '10.jpg',
            '11.jpg',
            '12.jpg',
            '13.jpg',
            '14.jpg',
            '15.jpg'
            
            );
            
            for($i=0; $i<=14;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/cls/<?=$cls[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--CLASSROOM-->
            
            
            <!--MISCELLANEOUS-->
			
            <div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
            <div class="grid__container">
            <div class="layout__regions grid__container--items" >
            <div  class="layout__region layout__region--main grid__container--item">
            <div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
            <div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
            <div class="c-rum-grid__content--inner c-grid__content--inner">
            <div class="c-rum-grid__header c-grid__header">
            <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
            <h3><br /><span style="color:#003a70;">MISCELLANEOUS</span></h3>
            <hr />
            <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
            <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
            <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
            <div class="c-button--inner">
            <div class="p-rum--cta p-atge-button--cta p-cta ">
            <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            <div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
            <div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
            <div class="field__item field__item-label-hidden">
            <div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
            <div class="view-content">
            
            
            
            
            <?php
            $mis= array(
            '1.jpg',
            '2.jpg',
            '3.jpg'
             
            
            );
            
            for($i=0; $i<=2;$i++){ ?>   
            <div class="views-row">
            <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
            <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
            
            
            
            <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
            
            <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
            <div class="" style="height: 100%;max-width: 100%;">
            <img src="images/gallery/mis/<?=$mis[$i]?>" typeof="foaf:Image" class="image-style-atge-no-style-lg" />
            
            
            </div>
            </div>
            
            
            </div>
            
            <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title">
            
            </div>
            
            <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
            
            </div>
            
            </a>
            
            </article>
            </div>
            <?php } ?>
            
            </div>
            
            </div>
            
            </div>
            </div>
            
            </div>
            
            </div>
            
            </div>
            
            
            
            </div>
            </div>
            
            
            
            
            
            </div>
            
            
            </div>
            </div>
            </div>
            
            <!--CLASSROOM-->
			<div class="t-layout__one-column standard-width layout__bg--none layout layout--atge-one-column" >
				<div class="grid__container">
					<div class="layout__regions grid__container--items" >
					<div  class="layout__region layout__region--main grid__container--item">
					<div data-block-plugin-id="inline_block:component_grid" data-inline-block-uuid="7e74f03c-20c5-4ffa-b2f9-1881ed679856" class="c-grid c-rum-grid block block-layout-builder block__inline-blockcomponent-grid">
					<div class="c-grid__content c-rum-grid__content p-banner__bg-color--none p-txt-align--left c-layout--fixed c-grid--content paragraph paragraph--type--atge-grid paragraph--view-mode--default c-atge-grid c-atge-grid--default">
					<div class="c-rum-grid__content--inner c-grid__content--inner">
                     <div class="c-rum-grid__header c-grid__header">
					 <div class="c-rum-grid__header--copy c-grid__header--copy p-txt-color--dark">
                      <h3><br /><span style="color:#003a70;">WUHS Belize  Videos</span></h3>
					  <hr />
					  <div data-embed-button="paragraphs" data-entity-label="Paragraphs" data-paragraph-id="8e86a422-6945-44f9-be11-fbd3195bd1d8" data-langcode="en" data-view-mode="embed" data-entity-embed-display="entity_reference:entity_reference_entity_view" data-entity-embed-display-settings="embed" data-entity-type="embedded_paragraphs" data-entity-uuid="8e86a422-6945-44f9-be11-fbd3195bd1d8" class="embedded-entity">
                      <div class="field field--name-paragraph field--type-entity-reference-revisions field--label-hidden field__item">
                     <div class="c-button c-rum-button paragraph paragraph--type--atge-button paragraph--view-mode--embed c-atge-button c-atge-button--embed">
                     <div class="c-button--inner">
                    <div class="p-rum--cta p-atge-button--cta p-cta ">
                   <a href="#" name="" aria-label="View ALL" target="" rel="" class="e-btn--primary" data-gtm="call-to-action" id="">View ALL<span class="e-icon"></span></a>
                   </div>
                    </div>
                     </div>
					 </div>
					 </div>
					 </div>
					 </div>
			<div class="c-view c-rum-view c-grid__layout--threecol p-txt-align--left paragraph paragraph--type--atge-view paragraph--view-mode--default c-atge-view c-atge-view--default">
			<div class="field field--name-field-atge-views-ref field--type-viewfield field--label-hidden">
			<div class="field__item field__item-label-hidden">
			<div class="views-element-container"><div class="view view-atge-news-tagged-listing view-id-atge_news_tagged_listing view-display-id-atge_news_tagged_featured_block js-view-dom-id-ecebe373d0d974c2750056e11f44758c9667f48a5fdb2e5c660ab60dbf46b5e8">
			<div class="view-content">
             
			 
			<div class="views-row">
			 <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
			 <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
                   <div class="t-article__grid--type t-rum-article__grid--media t-content-type__grid--type">Blog </div>
				   <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
				   <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
				   <div class="" style="height: 100%;max-width: 100%;">
                    <iframe width="420" height="315" src="https://www.youtube.com/embed/HFWdNC_bG6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				  </div>
				  </div>
				  </div>
				  <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
				  <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title"></div>
				  <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
				  </div>
			</a>
			</article>
			</div>
			
		<div class="views-row">
			 <article role="article" about="/about/blog/is-it-worth-going-to-medical-school" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
			 <a href="#" title="Is It Worth Going to Medical School?" aria-label="Is It Worth Going to Medical School?" data-gtm=&#039;call-to-action&#039;>
                   <div class="t-article__grid--type t-rum-article__grid--media t-content-type__grid--type">Blog </div>
				   <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
				   <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
				   <div class="" style="height: 100%;max-width: 100%;">
                    <iframe width="420" height="315" src="https://www.youtube.com/embed/vXa-cYNziTI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				  </div>
				  </div>
				  </div>
				  <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
				  <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title"></div>
				  <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
				  </div>
			</a>
			</article>
			</div>
			
    
    <div class="views-row">
	<article role="article" about="/about/blog/how-to-choose-a-medical-school-thats-right-for-you" class="t-article t-rum-article t-article__grid t-rum-article__grid t-content-type__grid node node--type-atge-article node--view-mode-grid">
	<a href="#" title="How to Choose a Medical School That’s Right for You" aria-label="How to Choose a Medical School That’s Right for You" data-gtm=&#039;call-to-action&#039;>
       <div class="t-article__grid--type t-rum-article__grid--media t-content-type__grid--type">Blog</div>
	   <div class="t-article__grid--media t-rum-article__grid--media t-content-type__grid--media has-objectfit">
       <div class="c-image c-rum-image paragraph paragraph--type--atge-media paragraph--view-mode--teaser c-atge-media c-atge-media--teaser">
          <div class="" style="height: 100%;max-width: 100%;">
                   <iframe width="420" height="315" src="https://www.youtube.com/embed/SYH05Mr8wgY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
		</div>
		</div>
    
        <div class="t-article__grid--content t-rum-article__grid--content t-content-type__grid--content">
            <div class="t-article__grid--title t-rum-article__grid--title t-content-type__grid--title"></div>
             <div class="t-article__grid--body t-rum-article__grid--body t-content-type__grid--body"></div>
         </div>
	 </a>
	 </article>
	 </div>

    </div>
  
          </div>
</div>

  </div>

    </div>

      </div>
  

    
          </div>
    </div>
	</div>
	</div>
	</div>
	</div>
	</article>
	</div>
</div>
			
			
			
			
 												
			
    </div>

  
</article>

  <style>
      
    .t-content-type__grid--media img {
    
    box-shadow: rgb(0 0 0 / 19%) 0px 10px 20px, rgb(0 0 0 / 23%) 0px 6px 6px;
    }
  </style>
    
</div>

      
                        </div>
  
		</div>
		
	</main>
	<footer role="contentinfo" class="page--footer">
<div class="region region__footer">
<div id="block-footer-sitebranding" data-block-plugin-id="system_branding_block" class="block block-system block-system-branding-block block__site-logo region--footer">
        <a href="../index.html" title="Home" rel="home"  class="e-logo" onClick="Drupal.behaviors.atgeAnalytics.navClick('Footer', 'logo')">
        <img loading="lazy"  alt="Washington University of Health and Science" class="footer-sitebranding" src="../images/footer-logo.png">
      </a>
  </div>
<div id="block-footer-address" data-block-plugin-id="block_content:a67ac222-6488-4aed-87c5-1d1cc3dba290" class="c-richtext c-rum-richtext block block-block-content block__block-contenta67ac222-6488-4aed-87c5-1d1cc3dba290">
<div class="c-richtext__content c-rum-richtext__content paragraph paragraph--type--atge-rich-text paragraph--view-mode--default c-atge-rich-text c-atge-rich-text--default">
<div class="c-richtext__content--inner c-rum-richtext__content--inner">
      <p>CAMPUS ADDRESS: Sea Star Drive,San Pedro, Ambergris Caye, Belize Central America.</p>

<p>USA ADMISSIONS ADDRESS: C/O American Academic Services,2602 Oakstone Dr, Suite 6,Columbus, OH 43231 </br>ADMISSIONS:  <a data-click-label="+501-6539581" data-gtm="phone" href="tel:+501-6539581"><strong>+501-6539581</strong></a><a data-click-label="+501-6540972" data-gtm="phone" href="tel:+501-6540972"><strong>+501-6540972</strong></a> EMAIL: <a href="admissions@wuhs.edu.bz">admissions@wuhs.edu.bz</a></p>

    </div>
      </div>    
</div>

<nav aria-labelledby="system-menu-blocksocial-media-block-socialmedianavigation-footer" id="block-socialmedianavigation" data-block-plugin-id="system_menu_block:social-media" class="block block-menu navigation menu--social-media">
            
  <h3 class="visually-hidden" id="system-menu-blocksocial-media-block-socialmedianavigation-footer">Social Media Navigation</h3>
  
        <ul class="menu menu--social-media">
        <li class="menu-item">
          <a href="https://www.facebook.com/wuhs.edu.bz" class="icon-link" aria-label="Facebook" data-gtm="social" data-click-action="link" data-click-label="Facebook" rel="nofollow" target="_blank" title="Facebook">          <span class="visually-hidden">Facebook</span>
          <span class="icon icon--facebook"></span>
        </a>
        </li>
		<!--<li class="menu-item">
          <a href="#" class="icon-link" aria-label="LinkedIn" data-gtm="social" data-click-action="link" data-click-label="LinkedIn" rel="nofollow" target="_blank" title="LinkedIn">          <span class="visually-hidden">LinkedIn</span>
          <span class="icon icon--linkedin"></span>
        </a>
        </li>-->
		<!--<li class="menu-item">
          <a href="#" class="icon-link" aria-label="TikTok" data-gtm="social" data-click-action="link" data-click-label="TikTok" rel="nofollow" target="_blank" title="TikTok">          <span class="visually-hidden">TikTok</span>
          <span class="icon icon--tiktok"></span>
        </a>
        </li>-->
		<li class="menu-item">
          <a href="https://twitter.com/wuhs1" class="icon-link" aria-label="Twitter" data-gtm="social" data-click-action="link" data-click-label="Twitter" rel="nofollow" target="_blank" title="Twitter">          <span class="visually-hidden">Twitter</span>
          <span class="icon icon--twitter"></span>
        </a>
        </li>
		<li class="menu-item">
          <a href="https://www.instagram.com/wuhsbelize/" class="icon-link" aria-label="Instagram" data-gtm="social" data-click-action="link" data-click-label="Instagram" rel="nofollow" target="_blank" title="Instagram">          <span class="visually-hidden">Instagram</span>
          <span class="icon icon--instagram"></span>
        </a>
        </li>
		<li class="menu-item">
          <a href="https://www.youtube.com/user/TheWUHSBelize/videos" class="icon-link" aria-label="YouTube" data-gtm="social" data-click-action="link" data-click-label="YouTube" rel="nofollow" target="_blank" title="YouTube">          <span class="visually-hidden">YouTube</span>
          <span class="icon icon--youtube"></span>
        </a>
        </li>
		<!--<li class="menu-item">
          <a href="#" class="icon-link" aria-label="Pinterest" data-gtm="social" data-click-action="link" data-click-label="Pinterest" rel="nofollow" target="_blank" title="Pinterest">          <span class="visually-hidden">Pinterest</span>
          <span class="icon icon--pinterest"></span>
        </a>
        </li>
		<li class="menu-item">
          <a href="#" class="icon-link" aria-label="SnapChat" data-gtm="social" data-click-action="link" data-click-label="SnapChat" rel="nofollow" target="_blank" title="SnapChat">          <span class="visually-hidden">SnapChat</span>
          <span class="icon icon--snapchat"></span>
        </a>
        </li>-->
          </ul>
  


  </nav>

<nav aria-labelledby="system-menu-blockfooter-block-footer-footer" id="block-footer" data-block-plugin-id="system_menu_block:footer" class="block block-menu navigation menu--footer">
            
  <h3 class="visually-hidden" id="system-menu-blockfooter-block-footer-footer">Footer Navigation</h3>
         <ul region="footer" class="menu">
               <li class="menu-item" >
                                <a href="../student-life/events.html" id="Info Sessions" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;Events &amp; Webinars&#039;)" data-drupal-link-system-path="node/131">Events</a>
                </li>
                <li class="menu-item" >
                                <a href="../contact-admissions.html" title="Contact wuhs" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;Contact wuhs&#039;)" data-drupal-link-system-path="node/51">Contact wuhs</a>
                 </li>
                 <li class="menu-item">
                                <a href="../about-overview.html" title="Request Information" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;Request Information&#039;)" data-drupal-link-system-path="node/2336">Request Information</a>
                 </li>
                 <li class="menu-item">
                                <a href="../student-life/life-at-wuhs-overview.html" title="Employment" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;EMPLOYMENT&#039;)">Srudent Life</a>
                 </li>
                 <li class="menu-item">
                                <a href="../admissions/how-to-apply.html" title="Privacy Policy" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;Privacy Policy&#039;)" data-drupal-link-system-path="node/616">Apply Now</a>
                 </li>
                 <li class="menu-item">
                                <a href="#" title="Sitemap" onClick="Drupal.behaviors.atgeAnalytics.navClick(&#039;Footer&#039;, &#039;Sitemap&#039;)" data-drupal-link-system-path="node/2301">Sitemap</a>
                 </li>
        </ul>
  

  </nav>
<div id="block-footer-copyright-and-links" data-block-plugin-id="block_content:3cd5a9db-fa14-45ec-a148-1bb3d87fc27e" class="c-richtext c-rum-richtext block block-block-content block__block-content3cd5a9db-fa14-45ec-a148-1bb3d87fc27e">
<div class="c-richtext__content c-rum-richtext__content paragraph paragraph--type--atge-rich-text paragraph--view-mode--default c-atge-rich-text c-atge-rich-text--default">
        
      <div class="c-richtext__content--inner c-rum-richtext__content--inner">
      <p><a href="../academic-overview.html">Academic </a> | <a href="../student-life/student-supportive-services.html" target="_blank">Student Handbook</a> | <a href="../student-life/international-students.html">International Student Information</a> | <a href="../student-life/canadian-students.html">Canadian Students</a> | <a href="../resource/2020-term-faqs.html">FAQS</a></p>

<p>© 2021 Washington University of Health and Science. All rights reserved.</p>

    </div>
      </div>   
</div></div>
  
</footer>
			
		

</div>

  </div>

    
    <script src="../sites/g/files/krcnkv261/files/js/js_jqd032sQaJrCKEqMTBpnsiyhCbZw0OdzbTv_eLvwLok.js"></script>

  </body>


</html>
